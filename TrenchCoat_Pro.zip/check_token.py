#!/usr/bin/env python3
"""
GitHub Token Renewal Reminder
Run this script to check token expiry
"""
import json
from datetime import datetime, timedelta

def check_token_expiry():
    try:
        with open("token_info.json", "r") as f:
            token_info = json.load(f)
        
        expires_date = datetime.fromisoformat(token_info["token_expires"])
        days_remaining = (expires_date - datetime.now()).days
        
        print(f"GitHub Token Status:")
        print(f"Expires: {expires_date.strftime('%Y-%m-%d')}")
        print(f"Days remaining: {days_remaining}")
        
        if days_remaining <= 0:
            print("\n!!! TOKEN EXPIRED !!!")
            print("Create new token: https://github.com/settings/tokens")
        elif days_remaining <= 7:
            print("\n!!! TOKEN EXPIRES SOON !!!")
            print("Create new token: https://github.com/settings/tokens")
        elif days_remaining <= 30:
            print("\nToken expires in less than 30 days")
            print("Consider creating renewal token soon")
        else:
            print("\nToken is valid")
            
    except FileNotFoundError:
        print("No token info found")

if __name__ == "__main__":
    check_token_expiry()